# PySigur
Python 3 API for Sigur OIF
